<?php
$a = file_get_contents('list.json');
$coin = json_decode($a)->data;
?>

<table border="1">
    <tr>
        <th>نماد</th>
        <th>قیمت</th>
        <th>حجم 24 ساعته</th>
        <th>تغییر در 24 ساعت اخیر</th>
        <th>تغییرات ساعتی</th>
        <th>تغییرات هفتگی</th>
        <th>تغییرات ماهانه</th>
        <th>تغییرات سه ماهه</th>
    </tr>
    <?php foreach ($coin as $coi): ?>
        <tr>
            <td><?php echo $coi->symbol; ?></td>
            <td><?php echo $coi->quote->USD->price; ?></td>
            <td><?php echo $coi->quote->USD->volume_24h; ?></td>
            <td><?php echo $coi->quote->USD->percent_change_24h; ?></td>
            <td><?php echo isset($coi->quote->USD->percent_change_1h) ? $coi->quote->USD->percent_change_1h : 'ناموجود'; ?></td>
            <td><?php echo isset($coi->quote->USD->percent_change_7d) ? $coi->quote->USD->percent_change_7d : 'ناموجود'; ?></td>
            <td><?php echo isset($coi->quote->USD->percent_change_30d) ? $coi->quote->USD->percent_change_30d : 'ناموجود'; ?></td>
            <td><?php echo isset($coi->quote->USD->percent_change_90d) ? $coi->quote->USD->percent_change_90d : 'ناموجود'; ?></td>
        </tr>
    <?php endforeach; ?>
</table>
