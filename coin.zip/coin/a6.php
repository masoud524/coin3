<?php
$a =file_get_contents('data/UNI.json');
$coin= json_decode($a);
foreach($coin as $coi){
    foreach($coi as $coin){
     print_r($coin);
     echo'</br>';
    }
}